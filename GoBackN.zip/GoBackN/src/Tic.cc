/*
// Tic.cc
#include "Tic.h"
#include "GoBackN_m.h"
#include <cmath>

Define_Module(Tic);

void Tic::initialize() {
    windowSizeW = 0;
    sendBase = 0;
    nextSeqNum = 0;
    timeoutEvent = new cMessage("timeoutEvent");
    sendTimer = new cMessage("sendTimer");
    unackedPackets.setName("unackedPackets");
    appQueue.setName("appQueue");
    isReceiverReady = true;
    int bits = par("seqNumBits");
    seqNumLimit = pow(2, bits);
    sentPkSignal = registerSignal("sentPkSignal");
    retransmitSignal = registerSignal("retransmitSignal");
    EV << "Sequence number limit set to " << seqNumLimit << " (" << bits << " bits)\n";

    GoBackNPacket *query = new GoBackNPacket("Query");
    query->setKind(QUERY_REQUEST);
    query->setSequenceNumber(0);
    send(query, "out");
}

void Tic::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        if (msg == sendTimer) {
            if (isReceiverReady && windowSizeW > 0 && nextSeqNum < sendBase + windowSizeW) {
                sendNextPacket();
            }
        } else if (msg == timeoutEvent) {
            EV << "!!! TIMEOUT expired. Resending window from seq=" << sendBase << "\n";
            bubble("Timeout! Resending.");
            emit(retransmitSignal, unackedPackets.getLength());
            for (cQueue::Iterator iter(unackedPackets); !iter.end(); ++iter) {
                GoBackNPacket *pkt = check_and_cast<GoBackNPacket *>(*iter);
                send(pkt->dup(), "out");
                EV << "--> Tic RE-sending, seq=" << pkt->getSequenceNumber() << "\n";
            }
            double timeout = par("timeout").doubleValue();
            scheduleAt(simTime() + timeout, timeoutEvent);
        }
        return;
    }

    if (msg->arrivedOn("appIn")) {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == GET) {
            EV << "Tic forwarding GET to AppServer\n";
            send(packet->dup(), "appOut");
            delete packet;
        } else {
            EV << "Tic queuing packet for GoBackN transmission\n";
            appQueue.insert(msg);
            if (windowSizeW > 0) {
                sendNextPacket();
            }
        }
        return;
    }

    if (msg->arrivedOn("appInData")) {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == DATA_FRAGMENT) {
            EV << "Tic queuing DATA_FRAGMENT for GoBackN transmission\n";
            appQueue.insert(msg);
            if (windowSizeW > 0) {
                sendNextPacket();
            }
        } else {
            delete msg;
        }
        return;
    }

    if (uniform(0, 1) < par("packetLossRate").doubleValue()) {
        EV << "!!! Tic: Incoming packet LOST (likely ACK/RR/RNR)\n";
        bubble("Incoming packet lost!");
        delete msg;
        return;
    }

    GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
    if (packet->getKind() == QUERY_REPLY) {
        windowSizeW = packet->getSequenceNumber();
        EV << "Tic received QUERY_REPLY with W=" << windowSizeW << "\n";
        cancelEvent(sendTimer);
        scheduleAt(simTime(), sendTimer);
        sendNextPacket();
    } else if (packet->getKind() == ACK) {
        int ackNum = packet->getSequenceNumber();
        EV << "<-- Tic received ACK for seq=" << ackNum << "\n";
        sendBase = ackNum;
        while (!unackedPackets.isEmpty()) {
            GoBackNPacket *pktInQueue = check_and_cast<GoBackNPacket *>(unackedPackets.front());
            if (pktInQueue->getSequenceNumber() == sendBase) {
                break;
            }
            delete (GoBackNPacket *)unackedPackets.pop();
        }
        cancelEvent(timeoutEvent);
        if (!unackedPackets.isEmpty()) {
            double timeout = par("timeout").doubleValue();
            scheduleAt(simTime() + timeout, timeoutEvent);
        }
        sendNextPacket();
    } else if (packet->getKind() == RNR) {
        EV << "<-- Tic received RNR. Pausing.\n";
        isReceiverReady = false;
    } else if (packet->getKind() == RR) {
        EV << "<-- Tic received RR. Resuming.\n";
        isReceiverReady = true;
        cancelEvent(sendTimer);
        scheduleAt(simTime(), sendTimer);
    }
    delete packet;
}

void Tic::sendNextPacket() {
    EV << "Tic::sendNextPacket() called - isReceiverReady=" << isReceiverReady 
       << ", nextSeqNum=" << nextSeqNum << ", sendBase=" << sendBase 
       << ", windowSizeW=" << windowSizeW << ", appQueue.length=" << appQueue.getLength() << "\n";
    
    if (windowSizeW <= 0) {
        EV << "Tic::sendNextPacket() - windowSizeW not set yet, waiting for QueryReply\n";
        return;
    }

    if (isReceiverReady && nextSeqNum < sendBase + windowSizeW && !appQueue.isEmpty()) {
        GoBackNPacket *pkt = check_and_cast<GoBackNPacket *>(appQueue.pop());
        if (pkt->getKind() != GET) {
            pkt->setSequenceNumber(nextSeqNum);
            send(pkt->dup(), "out");
            EV << "Tic sending " << pkt->getName() << ", seq=" << nextSeqNum
               << ", fragmentId=" << pkt->getFragmentId() << "\n";
            emit(sentPkSignal, 1L);
            unackedPackets.insert(pkt);
            nextSeqNum = (nextSeqNum + 1) % seqNumLimit;
            if (!timeoutEvent->isScheduled()) {
                double timeout = par("timeout").doubleValue();
                scheduleAt(simTime() + timeout, timeoutEvent);
            }
            // Calculate transmission time based on packet size and data rate
            double dataRate = par("dataRate").doubleValue();
            double packetSize = pkt->getByteLength();
            double transmissionTime = (packetSize * 8.0) / dataRate; // Convert to seconds

            // Schedule next send after transmission completes + small buffer
            cancelEvent(sendTimer);
            scheduleAt(simTime() + transmissionTime + 0.01, sendTimer);
            EV << "Tic scheduled next send at " << (simTime() + transmissionTime + 0.01)
               << " (transmission time: " << transmissionTime << "s)\n";
        } else {
            delete pkt;
        }
    } else {
        EV << "Tic::sendNextPacket() - no packets to send or conditions not met\n";
    }
}
*/

// Tic.cc
#include "Tic.h"
#include "GoBackN_m.h"
#include <cmath>

Define_Module(Tic);

void Tic::initialize() {
    windowSizeW = 0;
    sendBase = 0;
    nextSeqNum = 0;
    timeoutEvent = new cMessage("timeoutEvent");
    sendTimer = new cMessage("sendTimer");
    unackedPackets.setName("unackedPackets");
    appQueue.setName("appQueue");
    isReceiverReady = true;
    int bits = par("seqNumBits");
    seqNumLimit = pow(2, bits);
    sentPkSignal = registerSignal("sentPkSignal");
    retransmitSignal = registerSignal("retransmitSignal");
    EV << "Sequence number limit set to " << seqNumLimit << " (" << bits << " bits)\n";

    GoBackNPacket *query = new GoBackNPacket("Query");
    query->setKind(QUERY_REQUEST);
    query->setSequenceNumber(0);
    send(query, "out");
}

void Tic::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        if (msg == sendTimer) {
            if (isReceiverReady && windowSizeW > 0 && nextSeqNum < sendBase + windowSizeW) {
                sendNextPacket();
            }
        } else if (msg == timeoutEvent) {
            EV << "!!! TIMEOUT expired. Resending window from seq=" << sendBase << "\n";
            bubble("Timeout! Resending.");
            emit(retransmitSignal, unackedPackets.getLength());
            for (cQueue::Iterator iter(unackedPackets); !iter.end(); ++iter) {
                GoBackNPacket *pkt = check_and_cast<GoBackNPacket *>(*iter);
                send(pkt->dup(), "out");
                EV << "--> Tic RE-sending, seq=" << pkt->getSequenceNumber() << "\n";
            }
            double timeout = par("timeout").doubleValue();
            scheduleAt(simTime() + timeout, timeoutEvent);
        }
        return;
    }

    if (msg->arrivedOn("appIn")) {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == GET) {
            EV << "Tic forwarding GET to AppServer\n";
            send(packet->dup(), "appOut");
            delete packet;
        } else {
            EV << "Tic queuing packet for GoBackN transmission\n";
            appQueue.insert(msg);
            if (windowSizeW > 0) {
                sendNextPacket();
            }
        }
        return;
    }

    if (msg->arrivedOn("appInData")) {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == DATA_FRAGMENT) {
            EV << "Tic queuing DATA_FRAGMENT for GoBackN transmission (encrypted)\n";
            appQueue.insert(msg);
            if (windowSizeW > 0) {
                sendNextPacket();
            }
        } else {
            delete msg;
        }
        return;
    }

    if (uniform(0, 1) < par("packetLossRate").doubleValue()) {
        EV << "!!! Tic: Incoming packet LOST (likely ACK/RR/RNR)\n";
        bubble("Incoming packet lost!");
        delete msg;
        return;
    }

    GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
    if (packet->getKind() == QUERY_REPLY) {
        windowSizeW = packet->getSequenceNumber();
        EV << "Tic received QUERY_REPLY with W=" << windowSizeW << "\n";
        cancelEvent(sendTimer);
        scheduleAt(simTime(), sendTimer);
        sendNextPacket();
    } else if (packet->getKind() == ACK) {
        int ackNum = packet->getSequenceNumber();
        EV << "<-- Tic received ACK for seq=" << ackNum << "\n";
        sendBase = ackNum;
        while (!unackedPackets.isEmpty()) {
            GoBackNPacket *pktInQueue = check_and_cast<GoBackNPacket *>(unackedPackets.front());
            if (pktInQueue->getSequenceNumber() == sendBase) {
                break;
            }
            delete (GoBackNPacket *)unackedPackets.pop();
        }
        cancelEvent(timeoutEvent);
        if (!unackedPackets.isEmpty()) {
            double timeout = par("timeout").doubleValue();
            scheduleAt(simTime() + timeout, timeoutEvent);
        }
        sendNextPacket();
    } else if (packet->getKind() == RNR) {
        EV << "<-- Tic received RNR. Pausing.\n";
        isReceiverReady = false;
    } else if (packet->getKind() == RR) {
        EV << "<-- Tic received RR. Resuming.\n";
        isReceiverReady = true;
        cancelEvent(sendTimer);
        scheduleAt(simTime(), sendTimer);
    }
    delete packet;
}

void Tic::sendNextPacket() {
    EV << "Tic::sendNextPacket() called - isReceiverReady=" << isReceiverReady
       << ", nextSeqNum=" << nextSeqNum << ", sendBase=" << sendBase
       << ", windowSizeW=" << windowSizeW << ", appQueue.length=" << appQueue.getLength() << "\n";

    if (windowSizeW <= 0) {
        EV << "Tic::sendNextPacket() - windowSizeW not set yet, waiting for QueryReply\n";
        return;
    }

    if (isReceiverReady && nextSeqNum < sendBase + windowSizeW && !appQueue.isEmpty()) {
        GoBackNPacket *pkt = check_and_cast<GoBackNPacket *>(appQueue.pop());
        if (pkt->getKind() != GET) {
            pkt->setSequenceNumber(nextSeqNum);
            send(pkt->dup(), "out");
            EV << "Tic sending DATA_FRAGMENT, seq=" << nextSeqNum
               << ", fragmentId=" << pkt->getFragmentId() << " (encrypted)\n";
            emit(sentPkSignal, 1L);
            unackedPackets.insert(pkt);
            nextSeqNum = (nextSeqNum + 1) % seqNumLimit;
            if (!timeoutEvent->isScheduled()) {
                double timeout = par("timeout").doubleValue();
                scheduleAt(simTime() + timeout, timeoutEvent);
            }
            double dataRate = par("dataRate").doubleValue();
            double packetSize = pkt->getByteLength();
            double transmissionTime = (packetSize * 8.0) / dataRate;

            cancelEvent(sendTimer);
            scheduleAt(simTime() + transmissionTime + 0.01, sendTimer);
            EV << "Tic scheduled next send at " << (simTime() + transmissionTime + 0.01)
               << " (transmission time: " << transmissionTime << "s)\n";
        } else {
            delete pkt;
        }
    } else {
        EV << "Tic::sendNextPacket() - no packets to send or conditions not met\n";
    }
}
