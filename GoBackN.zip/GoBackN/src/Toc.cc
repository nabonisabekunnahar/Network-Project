/*
// Toc.cc
#include "Toc.h"
#include "GoBackN_m.h"

Define_Module(Toc);

void Toc::initialize() {
    windowSizeW = par("windowSizeW");
    expectedSeqNum = 0;
    buffer.setName("buffer");
    isReceiverReady = true;
    ackFreq = par("ackFreq");
    ackCounter = 0;
    packetsSinceLastAck = 0;
    isRnrState = false;
    receivedPkSignal = registerSignal("receivedPkSignal");
    lostPkSignal = registerSignal("lostPkSignal");
    EV << "Buffer Size (W): " << windowSizeW << ", ACK Freq (N): " << ackFreq << "\n";
}

void Toc::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        if (!buffer.isEmpty()) {
            EV << "Toc processing packet from buffer\n";
            GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(buffer.pop());
            if (packet) {
                if (packet->getKind() == DATA_FRAGMENT) {
                    send(packet->dup(), "appOut");
                    EV << "Toc forwarded fragment " << packet->getFragmentId() << " to AppClient\n";
                }
                delete packet;
            }
            if (isRnrState && buffer.getLength() < windowSizeW) {
                EV << "--> Toc buffer has space. Sending RR.\n";
                isRnrState = false;
                GoBackNPacket *rr = new GoBackNPacket("RR");
                rr->setKind(RR);
                rr->setSequenceNumber(expectedSeqNum);
                send(rr, "out");
            }
        }
        if (!buffer.isEmpty()) {
            scheduleAt(simTime() + 0.005, msg); // Reduced processing delay
        } else {
            delete msg;
        }
        return;
    }

    if (msg->arrivedOn("appIn")) {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == GET) {
            EV << "Toc forwarding GET to out\n";
            send(packet->dup(), "out");
        }
        delete msg;
        return;
    }

    if (uniform(0, 1) < par("packetLossRate").doubleValue()) {
        EV << "!!! Toc: Incoming packet LOST\n";
        bubble("Incoming packet lost!");
        delete msg;
        return;
    }

    GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
    if (packet->getKind() == QUERY_REQUEST) {
        EV << "Toc received QUERY_REQUEST, sending QueryReply with W=" << windowSizeW << "\n";
        GoBackNPacket *reply = new GoBackNPacket("QueryReply");
        reply->setKind(QUERY_REPLY);
        reply->setSequenceNumber(windowSizeW);
        send(reply, "out");
    } else if (packet->getKind() == DATA_FRAGMENT) {
        if (buffer.getLength() >= windowSizeW && !isRnrState) {
            EV << "!!! Toc buffer FULL. Sending RNR.\n";
            isRnrState = true;
            GoBackNPacket *rnr = new GoBackNPacket("RNR");
            rnr->setKind(RNR);
            rnr->setSequenceNumber(expectedSeqNum);
            send(rnr, "out");
        }

        if (packet->getSequenceNumber() == expectedSeqNum) {
            EV << "Toc received DATA_FRAGMENT, seq=" << expectedSeqNum << ", fragmentId=" << packet->getFragmentId() << "\n";
            emit(receivedPkSignal, 1L);
            bool bufferWasEmpty = buffer.isEmpty();
            buffer.insert(packet->dup());
            if (bufferWasEmpty) {
                scheduleAt(simTime() + 0.005, new cMessage("processingTimer")); // Reduced processing delay
            }
            expectedSeqNum = (expectedSeqNum + 1) % 8;
            packetsSinceLastAck++;
            // Strict ACK frequency enforcement
            if (packetsSinceLastAck >= par("ackFreq").intValue()) {
                GoBackNPacket *ack = new GoBackNPacket("Ack");
                ack->setKind(ACK);
                ack->setSequenceNumber(expectedSeqNum);
                send(ack, "out");
                EV << "--> Toc sending ACK for seq=" << expectedSeqNum << " (packetsSinceLastAck=" << packetsSinceLastAck << ")\n";
                packetsSinceLastAck = 0;
            }
        } else {
            EV << "!!! Toc received OUT-OF-ORDER, seq=" << packet->getSequenceNumber() << ". Expected: " << expectedSeqNum << "\n";
            GoBackNPacket *ack = new GoBackNPacket("Ack");
            ack->setKind(ACK);
            ack->setSequenceNumber(expectedSeqNum);
            send(ack, "out");
            EV << "--> Toc sending ACK for expected seq=" << expectedSeqNum << "\n";
            packetsSinceLastAck = 0;
        }
    }
    delete packet;
}
*/

// Toc.cc
#include "Toc.h"
#include "GoBackN_m.h"

Define_Module(Toc);

void Toc::initialize() {
    windowSizeW = par("windowSizeW");
    expectedSeqNum = 0;
    buffer.setName("buffer");
    isReceiverReady = true;
    ackFreq = par("ackFreq");
    ackCounter = 0;
    packetsSinceLastAck = 0;
    isRnrState = false;
    receivedPkSignal = registerSignal("receivedPkSignal");
    lostPkSignal = registerSignal("lostPkSignal");
    EV << "Buffer Size (W): " << windowSizeW << ", ACK Freq (N): " << ackFreq << "\n";
}

void Toc::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        if (!buffer.isEmpty()) {
            EV << "Toc processing packet from buffer\n";
            GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(buffer.pop());
            if (packet) {
                if (packet->getKind() == DATA_FRAGMENT) {
                    send(packet->dup(), "appOut");
                    EV << "Toc forwarded fragment " << packet->getFragmentId() << " to AppClient\n";
                }
                delete packet;
            }
            if (isRnrState && buffer.getLength() < windowSizeW) {
                EV << "--> Toc buffer has space. Sending RR.\n";
                isRnrState = false;
                GoBackNPacket *rr = new GoBackNPacket("RR");
                rr->setKind(RR);
                rr->setSequenceNumber(expectedSeqNum);
                send(rr, "out");
            }
        }
        if (!buffer.isEmpty()) {
            scheduleAt(simTime() + 0.005, msg); // Reduced processing delay
        } else {
            delete msg;
        }
        return;
    }

    if (msg->arrivedOn("appIn")) {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == GET) {
            EV << "Toc forwarding GET to out\n";
            send(packet->dup(), "out");
        }
        delete msg;
        return;
    }

    if (uniform(0, 1) < par("packetLossRate").doubleValue()) {
        EV << "!!! Toc: Incoming packet LOST\n";
        bubble("Incoming packet lost!");
        delete msg;
        return;
    }

    GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
    if (packet->getKind() == QUERY_REQUEST) {
        EV << "Toc received QUERY_REQUEST, sending QueryReply with W=" << windowSizeW << "\n";
        GoBackNPacket *reply = new GoBackNPacket("QueryReply");
        reply->setKind(QUERY_REPLY);
        reply->setSequenceNumber(windowSizeW);
        send(reply, "out");
    } else if (packet->getKind() == DATA_FRAGMENT) {
        if (buffer.getLength() >= windowSizeW && !isRnrState) {
            EV << "!!! Toc buffer FULL. Sending RNR.\n";
            isRnrState = true;
            GoBackNPacket *rnr = new GoBackNPacket("RNR");
            rnr->setKind(RNR);
            rnr->setSequenceNumber(expectedSeqNum);
            send(rnr, "out");
        }

        if (packet->getSequenceNumber() == expectedSeqNum) {
            EV << "Toc received DATA_FRAGMENT, seq=" << expectedSeqNum
               << ", fragmentId=" << packet->getFragmentId() << " (encrypted)\n";
            emit(receivedPkSignal, 1L);
            bool bufferWasEmpty = buffer.isEmpty();
            buffer.insert(packet->dup());
            if (bufferWasEmpty) {
                scheduleAt(simTime() + 0.005, new cMessage("processingTimer"));
            }
            expectedSeqNum = (expectedSeqNum + 1) % 8;
            packetsSinceLastAck++;
            if (packetsSinceLastAck >= par("ackFreq").intValue()) {
                GoBackNPacket *ack = new GoBackNPacket("Ack");
                ack->setKind(ACK);
                ack->setSequenceNumber(expectedSeqNum);
                send(ack, "out");
                EV << "--> Toc sending ACK for seq=" << expectedSeqNum
                   << " (confirmed, packetsSinceLastAck=" << packetsSinceLastAck << ")\n";
                packetsSinceLastAck = 0;
            }
        } else {
            EV << "!!! Toc received OUT-OF-ORDER, seq=" << packet->getSequenceNumber()
               << ". Expected: " << expectedSeqNum << "\n";
            GoBackNPacket *ack = new GoBackNPacket("Ack");
            ack->setKind(ACK);
            ack->setSequenceNumber(expectedSeqNum);
            send(ack, "out");
            EV << "--> Toc sending ACK for expected seq=" << expectedSeqNum << "\n";
            packetsSinceLastAck = 0;
        }
    }
    delete packet;
}
