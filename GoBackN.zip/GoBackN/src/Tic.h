// Tic.h
#ifndef __GOBACKN_TIC_H_
#define __GOBACKN_TIC_H_

#include <omnetpp.h>
using namespace omnetpp;

class Tic : public cSimpleModule {
private:
    int windowSizeW;
    int sendBase;
    int nextSeqNum;
    cMessage *timeoutEvent;
    cMessage *sendTimer;
    cQueue unackedPackets;
    cQueue appQueue;
    int seqNumLimit;
    bool isReceiverReady;
    simsignal_t sentPkSignal;     // Signal for sent packets
    simsignal_t retransmitSignal; // Signal for retransmissions
protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    void sendNextPacket();
};

#endif
