/*
 * AppServer.h
 *
 *  Created on: Oct 25, 2025
 *      Author: Win-10
 */
/*
// AppServer.h
#ifndef __GOBACKN_APPSERVER_H_
#define __GOBACKN_APPSERVER_H_

#include <omnetpp.h>
using namespace omnetpp;

class AppServer : public cSimpleModule {
protected:
    virtual void handleMessage(cMessage *msg) override;
    std::string xorEncrypt(const std::string &data);
};

#endif

*/

// AppServer.h
#ifndef __GOBACKN_APPSERVER_H_
#define __GOBACKN_APPSERVER_H_

#include <omnetpp.h>
#include "GoBackN_m.h"
#include <string>

using namespace omnetpp;

// Declare shared key as extern (definition is in AppServer.cc)
extern const char* xorKey;

class AppServer : public cSimpleModule {
protected:
    virtual void handleMessage(cMessage *msg) override;
    virtual void sendFragment(int fragmentId);

private:
    std::string xorEncrypt(const std::string& data, const char* key);
};

#endif
