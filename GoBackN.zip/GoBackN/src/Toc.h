// Toc.h
#ifndef __GOBACKN_TOC_H_
#define __GOBACKN_TOC_H_

#include <omnetpp.h>
using namespace omnetpp;

class Toc : public cSimpleModule {
private:
    int windowSizeW;
    int expectedSeqNum;
    cQueue buffer;
    bool isReceiverReady;
    int ackFreq;
    int ackCounter;
    int packetsSinceLastAck;
    bool isRnrState;
    simsignal_t receivedPkSignal;
    simsignal_t lostPkSignal;
protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

#endif
