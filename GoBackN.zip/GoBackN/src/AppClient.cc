/*
#include "AppClient.h"
#include "GoBackN_m.h"

Define_Module(AppClient);

void AppClient::initialize() {
    scheduleAt(simTime(), new cMessage("start"));
}

void AppClient::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        GoBackNPacket *get = new GoBackNPacket("GET");
        get->setKind(GET);
        send(get, "out");
        EV << "AppClient sent GET request\n";
    } else {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == DATA_FRAGMENT) {
            EV << "AppClient received fragment " << packet->getFragmentId() << "\n";
        }
        delete msg;
    }
}
*/

// AppClient.cc
#include "AppClient.h"
#include "GoBackN_m.h"
#include <string>

Define_Module(AppClient);

std::string AppClient::xorEncrypt(const std::string& data, const char* key) {
    std::string result = data;
    int keyLen = strlen(key);
    for (size_t i = 0; i < result.length(); ++i) {
        result[i] = result[i] ^ key[i % keyLen];
    }
    EV << "Encrypted data: " << result << "\n";
    return result;
}

std::string AppClient::xorDecrypt(const std::string& encrypted, const char* key) {
    int keyLen = strlen(key);

    // First, decode from the hex-like encoding (2 chars per byte)
    std::string decoded;
    for (size_t i = 0; i < encrypted.length(); i += 2) {
        if (i + 1 < encrypted.length()) {
            unsigned char high = (unsigned char)encrypted[i] - 48;
            unsigned char low = (unsigned char)encrypted[i + 1] - 48;

            // Combine nibbles back into byte
            unsigned char byte = (high << 4) | low;
            decoded += (char)byte;
        }
    }

    // Now apply XOR to decrypt (XOR is its own inverse)
    std::string result = decoded;
    for (size_t i = 0; i < result.length(); ++i) {
        result[i] = result[i] ^ key[i % keyLen];
    }

    EV << "Decrypt Debug - Input: '" << encrypted << "' (len=" << encrypted.length()
       << ") -> Decoded: (len=" << decoded.length() << ") -> Decrypted: '" << result << "'\n";
    return result;
}

void AppClient::initialize() {
    scheduleAt(simTime(), new cMessage("start"));
}

void AppClient::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage()) {
        GoBackNPacket *get = new GoBackNPacket("GET");
        get->setKind(GET);
        send(get, "out");
        EV << "AppClient sent GET request\n";
    } else {
        GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
        if (packet->getKind() == DATA_FRAGMENT) {
            std::string encryptedData = packet->getEncryptedData();
            std::string decrypted = xorDecrypt(encryptedData, xorKey);
            EV << "AppClient received fragment " << packet->getFragmentId()
               << " (decrypted: " << decrypted << ")\n";
        }
        delete msg;
    }
}
