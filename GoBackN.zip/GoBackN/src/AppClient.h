/*
 * AppClient.h
 *
 *  Created on: Oct 25, 2025
 *      Author: Win-10
 */
/*
#ifndef APPCLIENT_H_
#define APPCLIENT_H_

#include <omnetpp.h>
#include "GoBackN_m.h"

using namespace omnetpp;

class AppClient : public cSimpleModule
{
protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

#endif

*/

// AppClient.h
#ifndef APPCLIENT_H_
#define APPCLIENT_H_

#include <omnetpp.h>
#include "GoBackN_m.h"
#include "AppServer.h" // This includes the extern declaration of xorKey

using namespace omnetpp;

class AppClient : public cSimpleModule
{
protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

private:
    std::string xorEncrypt(const std::string& data, const char* key);
    std::string xorDecrypt(const std::string& encrypted, const char* key);
};

#endif /* APPCLIENT_H_ */
