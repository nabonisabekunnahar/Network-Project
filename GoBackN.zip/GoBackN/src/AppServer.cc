/*
#include "AppServer.h"
#include "GoBackN_m.h"

Define_Module(AppServer);

void AppServer::handleMessage(cMessage *msg) {
    EV << "AppServer received message: " << msg->getName() << "\n";
    GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
    if (packet->getKind() == GET) {
        int fileSize = par("fileSize").intValue();
        int chunkSize = par("chunkSize").intValue();
        int numFragments = (fileSize + chunkSize - 1) / chunkSize;
        EV << "AppServer received GET, sending " << numFragments << " fragments\n";
        for (int i = 0; i < numFragments; i++) {
            GoBackNPacket *fragment = new GoBackNPacket("DATA_FRAGMENT");
            fragment->setKind(DATA_FRAGMENT);
            fragment->setFragmentId(i);
            fragment->setEncryptedData(xorEncrypt("chunk_data").c_str());
            fragment->setByteLength(chunkSize);
            send(fragment, "out");
            EV << "AppServer sent fragment " << i << "\n";
        }
    } else {
        EV << "AppServer received non-GET packet: " << packet->getKind() << "\n";
    }
    delete msg;
}

std::string AppServer::xorEncrypt(const std::string &data) {
    std::string result = data;
    for (char &c : result) c ^= 0xFF;
    return result;
}
*/

// AppServer.cc
#include "AppServer.h"
#include "GoBackN_m.h"
#include <string>
#include <sstream>

Define_Module(AppServer);

// Define the XOR key HERE (only once in the entire project)
const char* xorKey = "mysecretkey123";

// Store encrypted data to keep it alive
std::vector<std::string> encryptedDataStore;

std::string AppServer::xorEncrypt(const std::string& data, const char* key) {
    std::string result = data;
    int keyLen = strlen(key);

    // XOR encryption
    for (size_t i = 0; i < result.length(); ++i) {
        result[i] = result[i] ^ key[i % keyLen];
    }

    // Convert to printable characters using Base64-like approach
    // Map each byte to printable ASCII without information loss
    std::string encoded;
    for (size_t i = 0; i < result.length(); ++i) {
        unsigned char c = (unsigned char)result[i];
        // Split byte into high and low nibbles
        unsigned char high = (c >> 4) & 0x0F;  // Upper 4 bits
        unsigned char low = c & 0x0F;           // Lower 4 bits

        // Map to printable characters (we use 48-63 range: '0'-'?')
        encoded += (char)(high + 48);
        encoded += (char)(low + 48);
    }

    EV << "Plaintext: '" << data << "' -> Encrypted: '" << encoded << "'\n";
    return encoded;
}

void AppServer::sendFragment(int fragmentId) {
    // Empty or implement fragment-specific logic if needed
}

void AppServer::handleMessage(cMessage *msg) {
    EV << "AppServer received message: " << msg->getName() << "\n";
    GoBackNPacket *packet = check_and_cast<GoBackNPacket *>(msg);
    if (packet->getKind() == GET) {
        int fileSize = par("fileSize").intValue();
        int chunkSize = par("chunkSize").intValue();
        int numFragments = (fileSize + chunkSize - 1) / chunkSize;
        EV << "AppServer received GET, sending " << numFragments << " fragments\n";

        // Clear previous encrypted data
        encryptedDataStore.clear();

        for (int i = 0; i < numFragments; i++) {
            GoBackNPacket *fragment = new GoBackNPacket("DATA_FRAGMENT");
            fragment->setKind(DATA_FRAGMENT);
            fragment->setFragmentId(i);

            std::stringstream ss;
            ss << "Fragment_" << i << "_Data";
            std::string plaintext = ss.str();

            std::string encrypted = xorEncrypt(plaintext, xorKey);

            // Store encrypted data to keep it alive
            encryptedDataStore.push_back(encrypted);

            // Use the stored string
            fragment->setEncryptedData(encryptedDataStore.back().c_str());
            fragment->setByteLength(chunkSize);
            send(fragment, "out");
            EV << "AppServer sent fragment " << i << " (encrypted)\n";
        }
    } else {
        EV << "AppServer received non-GET packet: " << packet->getKind() << "\n";
    }
    delete msg;
}
